<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/12/6
 * Time: 15:19
 */

namespace Home\Controller;


use Think\Controller;

class PersonalController extends Controller
{
    public function addressManagement(){
        $this->display();
    }
    public function personalCenter(){
        $this->display();
    }
}