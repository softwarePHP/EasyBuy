<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/12/6
 * Time: 15:04
 */

namespace Home\Controller;


use Think\Controller;

class OrderController extends Controller
{
    public function checkout(){
        $this->display();
    }
    public function order(){
        $this->display();
    }
    public function over(){
        $this->display();
    }
    public function payment(){
        $this->display();
    }
}