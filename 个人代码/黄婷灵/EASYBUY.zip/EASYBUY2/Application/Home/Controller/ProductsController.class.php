<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/12/6
 * Time: 15:20
 */

namespace Home\Controller;


use Think\Controller;

class ProductsController extends Controller
{
    public function products(){
        $this->display();
    }
    public function single(){
        $this->display();
    }
}