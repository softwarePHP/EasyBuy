<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>Personal Center</title>
	<link href="/EASYBUY2/Public/home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
	<link href="/EASYBUY2/Public/home/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="/EASYBUY2/Public/home/css/owl.carousel.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Swim Wear Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<script src="/EASYBUY2/Public/home/js/jquery.min.js"></script>
	<link href="/EASYBUY2/Public/home/css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/megamenu.js"></script>
	<!--<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>-->
	<!-- cart -->
	<script src="/EASYBUY2/Public/home/js/simpleCart.min.js"> </script>
	<!-- cart -->
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/bootstrap-3.1.1.min.js"></script>
	<script src="/EASYBUY2/Public/home/js/imagezoom.js"></script>

	<!-- FlexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

	<script>
		// Can also be used with $(document).ready()
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				controlNav: "thumbnails"
			});
		});
	</script>



</head>
<body>
<!--header-->
<div class="header">
	<div class="header-top">
		<div class="container">
			<div class="lang_list">
			</div>
			<div class="top-right">
				<ul>
					<li class="text"><a href="login.html">登录</a>
					<li><div class="cart box_1">
						<a href="checkout.html">
							<span class="simpleCart_total"> $0.00 </span> (<span id="simpleCart_quantity" class="simpleCart_quantity"> 0 </span>)
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">清空购物车</a></p>
						<div class="clearfix"> </div>
					</div></li>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="header-bottom">
		<div class="container">
			<!--/.content-->
			<div class="content white">
				<nav class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1 class="navbar-brand"><a  href="index.html">Easy Buy</a></h1>
					</div>
					<!--/.navbar-header-->

					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="index.html">主页</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">女士<b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-3">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">女士</a></li>-->
												<li><a class="list1" href="products.html">兰蔻(lancome)</a></li>
												<li><a class="list1" href="products.html">资生堂(shiseido)</a></li>
												<li><a class="list1" href="products.html">雅诗兰黛(estee lauder)</a></li>
												<li><a class="list1" href="products.html">迪奥(dior)</a></li>
												<li><a class="list1" href="products.html">香奈儿(chanel)</a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">男士</a></li>-->
												<li><a class="list1" href="products.html">碧欧泉(biotherm)</a></li>
												<li><a class="list1" href="products.html">赫莲娜(hr)</a></li>
												<li><a class="list1" href="products.html">伊丽莎白·雅顿(ea)</a></li>
												<li><a class="list1" href="products.html">百雀羚</a></li>
												<li><a class="list1" href="products.html"> </a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">

												<li><a class="list1" href="products.html">温碧泉</a></li>
												<li><a class="list1" href="products.html">植美村</a></li>
												<li><a class="list1" href="products.html">相宜本草</a></li>
												<li><a class="list1" href="products.html">欧莱雅</a></li>
												<li><a class="list1" href="products.html">丸美</a></li>
											</ul>
										</div>
									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">男士 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-2">
									<div class="row">
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">碧欧泉</a></li>
												<li><a class="list1" href="products.html">娇韵诗</a></li>
												<li><a class="list1" href="products.html">兰蔻</a></li>
												<li><a class="list1" href="products.html">欧珀莱</a></li>
												<li><a class="list1" href="products.html">资生堂</a></li>
											</ul>
										</div>
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">倩碧</a></li>
												<li><a class="list1" href="products.html">阿迪达斯</a></li>
												<li><a class="list1" href="products.html">雅男士</a></li>
												<li><a class="list1" href="products.html">杰士派</a></li>
												<li><a class="list1" href="products.html">高夫</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">儿童 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-1">
									<div class="row">
										<div class="col-sm-1">
											<ul class="multi-column-dropdown">
												<li><a class="list1" style="width:150px;" href="products.html">强生(Johnson)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝亲(Pigeon)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">施巴(Sebamed)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">妙思乐(mustela)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝比拉比</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li><a href="products.html">每日精选</a></li>

						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
				<!--/.navbar-->
			</div>
			<div class="search-box">
				<div id="sb-search" class="sb-search">
					<form>
						<input class="sb-search-input" placeholder="Enter your search term..." type="search" name="search" id="search">
						<input class="sb-search-submit" type="submit" value="">
						<span class="sb-icon-search"> </span>
					</form>
				</div>
			</div>

			<!-- search-scripts -->
			<script src="js/classie.js"></script>
			<script src="js/uisearch.js"></script>
			<script>
				new UISearch( document.getElementById( 'sb-search' ) );
			</script>
			<!-- //search-scripts -->
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--header-->
<div class="content">
	<!--start-contact-->
	<!--contact-->
	<div class="content">
		<div class="contact">
			<div class="container">
				<div class="contact-grids">
					<!--我写的开始-->
					<div class="container">
						<div class="row clearfix">
							<div class="col-md-2 column">
								<div class="panel-group" id="panel-966061">
									<div class="panel panel-default">
										<div class="panel-heading">
											<a class="panel-title collapsed" data-toggle="collapse" data-parent="#panel-966061" href="#panel-element-295698">我的交易</a>
										</div>
										<div id="panel-element-295698" class="panel-collapse collapse">
											<div class="panel-body">
												<a href = "personalCenter.html">我的订单</a>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<a class="panel-title collapsed" data-toggle="collapse" data-parent="#panel-966061" href="#panel-element-430327">我的账户</a>
										</div>
										<div id="panel-element-430327" class="panel-collapse collapse">
											<div class="panel-body">
												<a href = "addressManagement.html">地址管理</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-10 column">
								<div >
									<h1>
										我的订单
									</h1>
								</div>
								<br/>
								<div class="btn-group">
									<button class="btn btn-default" type="button"> 全部订单</button>
									<button class="btn btn-default" type="button"> 待付款</button>
									<button class="btn btn-default" type="button"> 待发货</button>
									<button class="btn btn-default" type="button"> 已发货</button>
									<button class="btn btn-default" type="button"> 已签收</button>
									<button class="btn btn-default" type="button"> 已取消</button>
									<button class="btn btn-default" type="button"> 已退货</button>
								</div>
								<table class="table">
									<thead>
									<tr>
										<th>
											订单信息
										</th>
										<th>
											商品
										</th>
										<th>
											订单金额
										</th>
										<th>
											订单状态
										</th>
										<th>
											操作
										</th>
									</tr>
									</thead>
									<tbody>
									<tr>
										<td>
											2016-11-21 订单号: 2833543413280707
										</td>
										<td>
											ROMOSS/罗马仕 小螺声宴 半入耳发烧级hifi音质 iphone5s/6s耳机
										</td>
										<td>
											￥79.00
										</td>
										<td>
											已发货
										</td>
										<td>
											<a href = "#">确认收货</a>
										</td>
									</tr>
									<tr class="success">
										<td>
											2016-11-30 订单号: 2858834605300707
										</td>
										<td>
											官方超快充—河北电信50元话费充值
										</td>
										<td>
											￥49.50
										</td>
										<td>
											已签收
										</td>
										<td>

										</td>
									</tr>
									<tr class="error">
										<td>
											2016-11-11 订单号: 2783353609320707
										</td>
										<td>
											【双11全球狂欢节】加厚不锈钢小火锅
										</td>
										<td>
											￥22.50
										</td>
										<td>
											已发货
										</td>
										<td>
											<a href = "#">确认收货</a>
										</td>
									</tr>
									<tr class="warning">
										<td>
											2016-11-11 订单号: 2756038231040707
										</td>
										<td>
											【双11全球狂欢节】罗曼丝蒂全棉斜纹枕套纯棉枕头套
										</td>
										<td>
											￥23.30
										</td>
										<td>
											已签收
										</td>
										<td>

										</td>
									</tr>
									<tr class="info">
										<td>
											2016-11-08 订单号: 2708152405080707
										</td>
										<td>
											【老徐外设店】宜博EMS109专用电子竞技鼠标LOL CF竞技游戏
										</td>
										<td>
											￥34.00
										</td>
										<td>
											已签收
										</td>
										<td>

										</td>
									</tr>
									</tbody>
								</table>
								<ul class="pagination">
									<li>
										<a href="#">上一页</a>
									</li>
									<li>
										<a href="#">1</a>
									</li>
									<li>
										<a href="#">2</a>
									</li>
									<li>
										<a href="#">3</a>
									</li>
									<li>
										<a href="#">4</a>
									</li>
									<li>
										<a href="#">下一页</a>
									</li>
								</ul>
							</div>
						</div>
					</div>






					<!--我写的结束-->
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>

	<!--footer-->
	<div class="footer-section">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-1 footer-grid">
				</div>
				<div class="col-md-2 footer-grid">
					<h4>新手指南</h4>
					<ul>
						<li><a href="products.html">购物流程</a></li>
						<li><a href="#">优惠券规则</a></li>
						<li><a href="#">联系客服</a></li>
						<li><a href="#">常见问题</a></li>

					</ul>
				</div>
				<div class="col-md-2 footer-grid">
					<h4>付款方式</h4>
					<ul>
						<li><a href="#">在线支付</a></li>
						<li><a href="#">货到付款</a></li>
						<li><a href="#">钱包支付</a></li>

					</ul>
				</div>
				<div class="col-md-2 footer-grid">
					<h4>配送方式</h4>
					<ul>
						<li><a href="#">配送时效及运费</a></li>
						<li><a href="#">验货与签收</a></li>

					</ul>
				</div>
				<div class="col-md-2 footer-grid">
					<h4>售后服务</h4>
					<ul>
						<li><a href="#">退货政策</a></li>
						<li><a href="#">退货流程</a></li>
						<li><a href="#">退货方式及时效</a></li>
					</ul>
				</div>
				<div class="col-md-2 footer-grid">
					<h4>部分合作网站</h4>
					<ul>
						<li><a href="www.lancome.com">兰蔻</a></li>
						<li><a href="#">雅诗兰黛</a></li>
						<li><a href="#">百雀羚</a></li>
					</ul>
				</div>
				<div class="col-md-1 footer-grid">
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-12 footer-grid1">
				<div class="col-md-5 footer-grid">
				</div>
				<div class="col-md-2 social-icons">
					<a href="#"><i class="icon"></i></a>
					<a href="#"><i class="icon1"></i></a>
					<a href="#"><i class="icon2"></i></a>
					<a href="#"><i class="icon3"></i></a>
					<a href="#"><i class="icon4"></i></a>
					<p>Copyright &copy; 易购商城</p>
				</div>
				<div class="col-md-5 footer-grid">
				</div>
			</div>
		</div>
	</div>
	<!--footer-->

</body>
</html>