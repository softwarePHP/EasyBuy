<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>支付页</title>
	<meta http-equiv="x-ua-compatible" content="IE=edge">
	<title>收银台_乐蜂网</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<link rel="stylesheet" type="text/css" href="/EASYBUY2/Public/home/css/global.css">
	<link rel="stylesheet" type="text/css" href="/EASYBUY2/Public/home/css/pay-cashier.css">
	<script type="text/javascript" async="" src="/EASYBUY2/Public/home/js/vds.js"></script><script type="text/javascript" src="/EASYBUY2/Public/home/js/es5-shim.min.js"></script>
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/vds(1).js"></script>
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/global.js"></script>
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/pay-cashier.js"></script>
	<link href="/EASYBUY2/Public/home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
	<link href="/EASYBUY2/Public/home/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="/EASYBUY2/Public/home/css/owl.carousel.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Swim Wear Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<script src="/EASYBUY2/Public/home/js/jquery.min.js"></script>
	<!-- cart -->
	<script src="/EASYBUY2/Public/home/js/simpleCart.min.js"> </script>
	<!-- cart -->
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/bootstrap-3.1.1.min.js"></script>
	<script src="/EASYBUY2/Public/home/js/imagezoom.js"></script>

	<!-- FlexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

	<script>
		// Can also be used with $(document).ready()
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				controlNav: "thumbnails"
			});
		});
	</script>
</head>
<body class="bj Wmin">

<script type="text/javascript" src="/EASYBUY2/Public/home//js/mars_vipapp.js"></script>

<script src="/EASYBUY2/Public/home//js/pc-mar.js"></script>
<!--header-->
<div class="header">
	<div class="header-top">
		<div class="container">
			<div class="top-right">
				<ul>
					<li class="text"><a href="login.html">登录</a>
					<li class="text"><a href="login.html">退出</a>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="header-bottom">
		<div class="container">
			<script type="text/javascript" src='jquery-1.7.1.min.js'></script>
			<script type="text/javascript">
				$(function() {
					setTimeout("changeDivStyle();", 100); // 0.1秒后展示结果，因为HTML加载顺序，先加载脚本+样式，再加载body内容。所以加个延时
				});
				function changeDivStyle(){
//		var o_status = $("#o_status").val();	//获取隐藏框值
					var o_status = 4;
					if(o_status==0){
						$('#create').css('background', '#DD0000');
						$('#createText').css('color', '#DD0000');
					}else if(o_status==1||o_status==2){
						$('#check').css('background', '#DD0000');
						$('#checkText').css('color', '#DD0000');
					}else if(o_status==3){
						$('#produce').css('background', '#DD0000');
						$('#produceText').css('color', '#DD0000');
					}else if(o_status==4){
						$('#delivery').css('background', '#DD0000');
						$('#deliveryText').css('color', '#DD0000');
					}else if(o_status>=5){
						$('#received').css('background', '#DD0000');
						$('#receivedText').css('color', '#DD0000');
					}
				}
			</script>



			<style type="text/css">
				*{margin:0;padding:0;list-style-type:none;}
				a,img{border:0;}
				body{background:#f2f2f2;font:12px/180% Arial, Helvetica, sans-serif, "新宋体";}
				/* stepInfo
                    border-radius：0为正方形，0~N，由正方形向圆形转化，N越大越圆。
                    padding：图形的内边距
                    background：图形背景色
                    text-align：文本对齐
                    line-height：行高
                    color：文字颜色
                    position：定位
                    width：宽度
                    height：高度
                */
				.stepInfo{position:relative;background:#f2f2f2;margin:20px auto 0 auto;width:500px;}
				.stepInfo li{float:left;width:48%;height:0.15em;background:#bbb;}
				.stepIco{border-radius:1em;padding:0.03em;background:#bbb;text-align:center;line-height:1.5em;color:#fff; position:absolute;width:1.4em;height:1.4em;}
				.stepIco1{top:-0.7em;left:-1%;}
				.stepIco2{top:-0.7em;left:21%;}
				.stepIco3{top:-0.7em;left:46%;}
				.stepIco4{top:-0.7em;left:71%;}
				.stepIco5{top:-0.7em;left:95%;}
				.stepText{color:#666;margin-top:0.2em;width:4em;text-align:center;margin-left:-1.4em;}
			</style>




			<input type="hidden" value=${detailorder.status } id="o_status" /><!--后台传到页面的数据-->




			<div class="stepInfo">
				<ul>
					<li></li>
					<li></li>
				</ul>
				<div class="stepIco stepIco1" id="create">1
					<div class="stepText" id="createText">加入购物车</div>
				</div>
				<div class="stepIco stepIco2" id="check">2
					<div class="stepText" id="checkText">审核订单</div>
				</div>
				<div class="stepIco stepIco3" id="produce">3
					<div class="stepText" id="produceText">订单详情</div>
				</div>
				<div class="stepIco stepIco4" id="delivery">4
					<div class="stepText" id="deliveryText">付款</div>
				</div>
				<div class="stepIco stepIco5" id="received">5
					<div class="stepText" id="receivedText">付款成功</div>
				</div>
			</div>






			<div style="text-align:center;margin:120px 0; font:normal 14px/24px 'MicroSoft YaHei';clear:both;">
				<div class="cart3-complete">
					<p style="text-align:left"><div class="fr w850" >
					<h1>订单提交成功！仅差一步完成抢购，请尽快支付！</h1>
					<div class="lie">共1张订单， <a href="order.html" target="_blank">订单详情</a>
						<div class="lif">待支付：¥<strong class="u-price">89.00</strong></div>
					</div>
					</p>
					<div class="cart5-bank">
						<div class="box">
							<ul>
								<li data-payid="501" data-paytype="159" data-payname="weixin" class="pm_bank_selected"><img src="/EASYBUY2/Public/home/images/1314.png">

								</li>
								<li data-payid="500" data-paytype="163" data-payname="alipay" class="pm_bank_selected">
									<img src="/EASYBUY2/Public/home/images/tangyuan.png">
								</li>
							</ul>
						</div>
						<div class="clearfloat"></div>
						<div class="box-but">
							<input name="" type="button" value="前往支付" onclick="location='over.html'" class="pre"> 请选择支付方式
						</div>
					</div>
				</div>
				<div class="cart4-b po_not_payonline"><!--不想在线支付了？  <a href="#">改用货到付款</a>--></div>
			</div>


			<div style=" margin-left: auto; margin-right: auto; height: 50px;">
			</div>
			<!--footer-->

			<div style=" margin-left: auto; margin-right: auto;">
				<div class="container">
					<div class="footer-grids">
						<div class="col-md-1 footer-grid">
						</div>
						<div class="col-md-2 footer-grid">
							<h4>新手指南</h4>
							<ul>
								<li><a href="products.html">购物流程</a></li>
								<li><a href="#">优惠券规则</a></li>
								<li><a href="#">联系客服</a></li>
								<li><a href="#">常见问题</a></li>

							</ul>
						</div>
						<div class="col-md-2 footer-grid">
							<h4>付款方式</h4>
							<ul>
								<li><a href="#">在线支付</a></li>
								<li><a href="#">货到付款</a></li>
								<li><a href="#">钱包支付</a></li>

							</ul>
						</div>
						<div class="col-md-2 footer-grid">
							<h4>配送方式</h4>
							<ul>
								<li><a href="#">配送时效及运费</a></li>
								<li><a href="#">验货与签收</a></li>

							</ul>
						</div>
						<div class="col-md-2 footer-grid">
							<h4>售后服务</h4>
							<ul>
								<li><a href="#">退货政策</a></li>
								<li><a href="#">退货流程</a></li>
								<li><a href="#">退货方式及时效</a></li>
							</ul>
						</div>
						<div class="col-md-2 footer-grid">
							<h4>部分合作网站</h4>
							<ul>
								<li><a href="www.lancome.com">兰蔻</a></li>
								<li><a href="#">雅诗兰黛</a></li>
								<li><a href="#">百雀羚</a></li>
							</ul>
						</div>
						<div class="col-md-1 footer-grid">
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-12 footer-grid1">
						<div class="col-md-5 footer-grid">
						</div>
						<div class="col-md-2 social-icons">
							<a href="#"><i class="icon"></i></a>
							<a href="#"><i class="icon1"></i></a>
							<a href="#"><i class="icon2"></i></a>
							<a href="#"><i class="icon3"></i></a>
							<a href="#"><i class="icon4"></i></a>
							<p>Copyright &copy; 易购商城</p>
						</div>
						<div class="col-md-5 footer-grid">
						</div>
					</div>
				</div>
			</div>
			<!--footer-->
</body>
</html>