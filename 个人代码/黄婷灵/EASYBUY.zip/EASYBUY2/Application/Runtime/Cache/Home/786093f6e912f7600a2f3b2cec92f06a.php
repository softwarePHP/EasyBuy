<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>Search页面</title>
	<link href="/EASYBUY2/Public/home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
	<link href="/EASYBUY2/Public/home/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="/EASYBUY2/Public/home/css/owl.carousel.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Swim Wear Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<script src="/EASYBUY2/Public/home/js/jquery.min.js"></script>
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/bootstrap-3.1.1.min.js"></script>
	<!-- cart -->
	<script src="/EASYBUY2/Public/home/js/simpleCart.min.js"> </script>
	<!-- cart -->
	<!-- the jScrollPane script -->
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/jquery.jscrollpane.min.js"></script>
	<script type="text/javascript" id="sourcecode">
		$(function()
		{
			$('.scroll-pane').jScrollPane();
		});
	</script>
	<!-- //the jScrollPane script -->
	<link href="/EASYBUY2/Public/home/css/form.css" rel="stylesheet" type="text/css" media="all" />
	<!-- the mousewheel plugin -->
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/jquery.mousewheel.js"></script>
</head>
<body>
<!--header-->
<div class="header">
	<div class="header-top">
		<div class="container">

			<div class="top-right">
				<ul>
					<li class="text"><a href="login.html">登录</a>
					<li><div class="cart box_1">
						<a href="checkout.html">
							<span class="simpleCart_total"> ￥0.00 </span> (<span id="simpleCart_quantity" class="simpleCart_quantity"> 0 </span>)
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">清空购物车</a></p>
						<div class="clearfix"> </div>
					</div></li>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="header-bottom">
		<div class="container">
			<!--/.content-->
			<div class="content white">
				<nav class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1 class="navbar-brand"><a  href="index.html">Easy Buy</a></h1>
					</div>
					<!--/.navbar-header-->

					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="index.html">主页</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">女士<b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-3">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">女士</a></li>-->
												<li><a class="list1" href="products.html">兰蔻(lancome)</a></li>
												<li><a class="list1" href="products.html">资生堂(shiseido)</a></li>
												<li><a class="list1" href="products.html">雅诗兰黛(estee lauder)</a></li>
												<li><a class="list1" href="products.html">迪奥(dior)</a></li>
												<li><a class="list1" href="products.html">香奈儿(chanel)</a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">男士</a></li>-->
												<li><a class="list1" href="products.html">碧欧泉(biotherm)</a></li>
												<li><a class="list1" href="products.html">赫莲娜(hr)</a></li>
												<li><a class="list1" href="products.html">伊丽莎白·雅顿(ea)</a></li>
												<li><a class="list1" href="products.html">百雀羚</a></li>
												<li><a class="list1" href="products.html"> </a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">

												<li><a class="list1" href="products.html">温碧泉</a></li>
												<li><a class="list1" href="products.html">植美村</a></li>
												<li><a class="list1" href="products.html">相宜本草</a></li>
												<li><a class="list1" href="products.html">欧莱雅</a></li>
												<li><a class="list1" href="products.html">丸美</a></li>
											</ul>
										</div>
									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">男士 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-2">
									<div class="row">
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">碧欧泉</a></li>
												<li><a class="list1" href="products.html">娇韵诗</a></li>
												<li><a class="list1" href="products.html">兰蔻</a></li>
												<li><a class="list1" href="products.html">欧珀莱</a></li>
												<li><a class="list1" href="products.html">资生堂</a></li>
											</ul>
										</div>
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">倩碧</a></li>
												<li><a class="list1" href="products.html">阿迪达斯</a></li>
												<li><a class="list1" href="products.html">雅男士</a></li>
												<li><a class="list1" href="products.html">杰士派</a></li>
												<li><a class="list1" href="products.html">高夫</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">儿童 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-1">
									<div class="row">
										<div class="col-sm-1">
											<ul class="multi-column-dropdown">
												<li><a class="list1" style="width:150px;" href="products.html">强生(Johnson)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝亲(Pigeon)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">施巴(Sebamed)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">妙思乐(mustela)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝比拉比</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li><a href="products.html">每日精选</a></li>

						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
				<!--/.navbar-->
			</div>
			<div class="search-box">
				<div id="sb-search" class="sb-search">
					<form>
						<input class="sb-search-input" placeholder="输入你想要搜索的内容..." type="search" name="search" id="search">
						<input class="sb-search-submit" type="submit" value="">
						<span class="sb-icon-search"> </span>
					</form>
				</div>
			</div>

			<!-- search-scripts -->
			<script src="/EASYBUY2/Public/home/js/classie.js"></script>
			<script src="/EASYBUY2/Public/home/js/uisearch.js"></script>
			<script>
				new UISearch( document.getElementById( 'sb-search' ) );
			</script>
			<!-- //search-scripts -->
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--header-->
<div class="content">
	<div class="product-model">
		<div class="container">
			<h2>Our Products</h2>
			<div class="col-md-9 product-model-sec">
				<a href="single.html"><div class="product-grid">
					<div class="more-product"><span> </span></div>
					<div class="product-img b-link-stripe b-animate-go  thickbox">
						<img src="images/p1.jpg" class="img-responsive" alt="">
						<div class="b-wrapper">
							<h4 class="b-animate b-from-left  b-delay03">
								<button> + </button>
							</h4>
						</div>
					</div>
				</a>
				<div class="product-info simpleCart_shelfItem">
					<div class="product-info-cust prt_name">
						<h4>兰蔻小黑瓶精华肌底液</h4>
						<span class="item_price">￥799</span>
						<div class="ofr">
							<p class="pric1"><del>Rs ￥999</del></p>
							<p class="disc">[8折]</p>
						</div>
						<input type="text" class="item_quantity" value="1" />
						<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
			<a href="single.html"><div class="product-grid">
				<div class="more-product"><span> </span></div>
				<div class="product-img b-link-stripe b-animate-go  thickbox">
					<img src="/EASYBUY2/Public/home/images/p1.jpg" class="img-responsive" alt="">
					<div class="b-wrapper">
						<h4 class="b-animate b-from-left  b-delay03">
							<button> + </button>
						</h4>
					</div>
				</div>
			</a>
			<div class="product-info simpleCart_shelfItem">
				<div class="product-info-cust prt_name">
					<h4>兰蔻小黑瓶精华肌底液</h4>
					<span class="item_price">￥799</span>
					<div class="ofr">
						<p class="pric1"><del>Rs ￥999</del></p>
						<p class="disc">[8折]</p>
					</div>
					<input type="text" class="item_quantity" value="1" />
					<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<a href="single.html"><div class="product-grid">
			<div class="more-product"><span> </span></div>
			<div class="product-img b-link-stripe b-animate-go  thickbox">
				<img src="/EASYBUY2/Public/home/images/p1.jpg" class="img-responsive" alt="">
				<div class="b-wrapper">
					<h4 class="b-animate b-from-left  b-delay03">
						<button> + </button>
					</h4>
				</div>
			</div>
		</a>
		<div class="product-info simpleCart_shelfItem">
			<div class="product-info-cust prt_name">
				<h4>兰蔻小黑瓶精华肌底液</h4>
				<span class="item_price">￥799</span>
				<div class="ofr">
					<p class="pric1"><del>Rs ￥999</del></p>
					<p class="disc">[8折]</p>
				</div>
				<input type="text" class="item_quantity" value="1" />
				<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<a href="single.html"><div class="product-grid">
		<div class="more-product"><span> </span></div>
		<div class="product-img b-link-stripe b-animate-go  thickbox">
			<img src="/EASYBUY2/Public/home/images/p2.jpg" class="img-responsive" alt=""/>
			<div class="b-wrapper">
				<h4 class="b-animate b-from-left  b-delay03">
					<button> + </button>
				</h4>
			</div>
		</div>
	</a>
	<div class="product-info simpleCart_shelfItem">
		<div class="product-info-cust prt_name">
			<h4>Absolue L’extrait Inconparable Elixir 兰蔻黑金臻宠精华乳</h4>
			<span class="item_price">￥4259</span>
			<div class="ofr">
				<p class="pric1"><del>Rs ￥4300</del></p>
				<p class="disc">[9.9折]</p>
			</div>
			<input type="text" class="item_quantity" value="1" />
			<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<a href="single.html"><div class="product-grid">
	<div class="more-product"><span> </span></div>
	<div class="product-img b-link-stripe b-animate-go  thickbox">
		<img src="/EASYBUY2/Public/home/images/p2.jpg" class="img-responsive" alt=""/>
		<div class="b-wrapper">
			<h4 class="b-animate b-from-left  b-delay03">
				<button> + </button>
			</h4>
		</div>
	</div>
</a>
<div class="product-info simpleCart_shelfItem">
	<div class="product-info-cust prt_name">
		<h4>Absolue L’extrait Inconparable Elixir 兰蔻黑金臻宠精华乳</h4>
		<span class="item_price">￥4259</span>
		<div class="ofr">
			<p class="pric1"><del>Rs ￥4300</del></p>
			<p class="disc">[9.9折]</p>
		</div>
		<input type="text" class="item_quantity" value="1" />
		<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
		<div class="clearfix"> </div>
	</div>
</div>
</div>
<a href="single.html"><div class="product-grid">
	<div class="more-product"><span> </span></div>
	<div class="product-img b-link-stripe b-animate-go  thickbox">
		<img src="/EASYBUY2/Public/home/images/p2.jpg" class="img-responsive" alt=""/>
		<div class="b-wrapper">
			<h4 class="b-animate b-from-left  b-delay03">
				<button> + </button>
			</h4>
		</div>
	</div>
</a>
<div class="product-info simpleCart_shelfItem">
	<div class="product-info-cust prt_name">
		<h4>Absolue L’extrait Inconparable Elixir 兰蔻黑金臻宠精华乳</h4>
		<span class="item_price">￥4259</span>
		<div class="ofr">
			<p class="pric1"><del>Rs ￥4300</del></p>
			<p class="disc">[9.9折]</p>
		</div>
		<input type="text" class="item_quantity" value="1" />
		<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
		<div class="clearfix"> </div>
	</div>
</div>
</div>

<a href="single.html"><div class="product-grid">
	<div class="more-product"><span> </span></div>
	<div class="product-img b-link-stripe b-animate-go  thickbox">
		<img src="/EASYBUY2/Public/home/images/p3.jpg" class="img-responsive" alt=""/>
		<div class="b-wrapper">
			<h4 class="b-animate b-from-left  b-delay03">
				<button> + </button>
			</h4>
		</div>
	</div>	</a>
<div class="product-info simpleCart_shelfItem">
	<div class="product-info-cust prt_name">
		<h4>Blanc Expert Integral Whiteness Spot Eraser 兰蔻臻白淡斑精华乳</h4>
		<span class="item_price">￥829</span>
		<div class="ofr">
			<p class="pric1"><del>Rs ￥1040</del></p>
			<p class="disc">[8折]</p>
		</div>
		<input type="text" class="item_quantity" value="1" />
		<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
		<div class="clearfix"> </div>
	</div>
</div>
</div>
<a href="single.html"><div class="product-grid">
	<div class="more-product"><span> </span></div>
	<div class="product-img b-link-stripe b-animate-go  thickbox">
		<img src="/EASYBUY2/Public/home/images/p3.jpg" class="img-responsive" alt=""/>
		<div class="b-wrapper">
			<h4 class="b-animate b-from-left  b-delay03">
				<button> + </button>
			</h4>
		</div>
	</div>	</a>
<div class="product-info simpleCart_shelfItem">
	<div class="product-info-cust prt_name">
		<h4>Blanc Expert Integral Whiteness Spot Eraser 兰蔻臻白淡斑精华乳</h4>
		<span class="item_price">￥829</span>
		<div class="ofr">
			<p class="pric1"><del>Rs ￥1040</del></p>
			<p class="disc">[8折]</p>
		</div>
		<input type="text" class="item_quantity" value="1" />
		<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
		<div class="clearfix"> </div>
	</div>
</div>
</div>
<a href="single.html"><div class="product-grid">
	<div class="more-product"><span> </span></div>
	<div class="product-img b-link-stripe b-animate-go  thickbox">
		<img src="/EASYBUY2/Public/home/images/p3.jpg" class="img-responsive" alt=""/>
		<div class="b-wrapper">
			<h4 class="b-animate b-from-left  b-delay03">
				<button> + </button>
			</h4>
		</div>
	</div>	</a>
<div class="product-info simpleCart_shelfItem">
	<div class="product-info-cust prt_name">
		<h4>Blanc Expert Integral Whiteness Spot Eraser 兰蔻臻白淡斑精华乳</h4>
		<span class="item_price">￥829</span>
		<div class="ofr">
			<p class="pric1"><del>Rs ￥1040</del></p>
			<p class="disc">[8折]</p>
		</div>
		<input type="text" class="item_quantity" value="1" />
		<a href = "checkout.html"><input type="button" class="item_add items" value="+"></a>
		<div class="clearfix"> </div>
	</div>
</div>
</div>


</div>
<div class="rsidebar span_1_of_left">
	<section  class="sky-form">
		<div class="product_right">
			<h4 class="m_2"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>种类</h4>
			<div class="tab1">
				<ul class="place">
					<li class="sort">全部商品</li>
					<li class="by"><img src="images/do.png" alt=""></li>
					<div class="clearfix"> </div>
				</ul>
				<div class="single-bottom">
					<a href="#"><p>护肤用品</p></a>
					<a href="#"><p>彩妆用品</p></a>
					<a href="#"><p>美容工具</p></a>
					<a href="#"><p>香水香氛</p></a>
					<a href="#"><p>个人护理</p></a>
				</div>
			</div>
			<div class="tab2">
				<ul class="place">
					<li class="sort">女士专区</li>
					<li class="by"><img src="images/do.png" alt=""></li>
					<div class="clearfix"> </div>
				</ul>
				<div class="single-bottom">
					<a href="#"><p>彩妆</p></a>
					<a href="#"><p>护肤</p></a>
				</div>
			</div>
			<div class="tab3">
				<ul class="place">
					<li class="sort">男士专区</li>
					<li class="by"><img src="images/do.png" alt=""></li>
					<div class="clearfix"> </div>
				</ul>
				<div class="single-bottom">
					<a href="#"><p>运动</p></a>
				</div>
			</div>
			<div class="tab4">
				<ul class="place">
					<li class="sort">儿童专区</li>
					<li class="by"><img src="images/do.png" alt=""></li>
					<div class="clearfix"> </div>
				</ul>
				<div class="single-bottom">
					<a href="#"><p>滋养</p></a>
					<a href="#"><p>美白</p></a>
					<a href="#"><p>补水</p></a>
				</div>
			</div>
			<!--script-->
			<script>
				$(document).ready(function(){
					$(".tab1 .single-bottom").hide();
					$(".tab2 .single-bottom").hide();
					$(".tab3 .single-bottom").hide();
					$(".tab4 .single-bottom").hide();
					$(".tab5 .single-bottom").hide();

					$(".tab1 ul").click(function(){
						$(".tab1 .single-bottom").slideToggle(300);
						$(".tab2 .single-bottom").hide();
						$(".tab3 .single-bottom").hide();
						$(".tab4 .single-bottom").hide();
						$(".tab5 .single-bottom").hide();
					})
					$(".tab2 ul").click(function(){
						$(".tab2 .single-bottom").slideToggle(300);
						$(".tab1 .single-bottom").hide();
						$(".tab3 .single-bottom").hide();
						$(".tab4 .single-bottom").hide();
						$(".tab5 .single-bottom").hide();
					})
					$(".tab3 ul").click(function(){
						$(".tab3 .single-bottom").slideToggle(300);
						$(".tab4 .single-bottom").hide();
						$(".tab5 .single-bottom").hide();
						$(".tab2 .single-bottom").hide();
						$(".tab1 .single-bottom").hide();
					})
					$(".tab4 ul").click(function(){
						$(".tab4 .single-bottom").slideToggle(300);
						$(".tab5 .single-bottom").hide();
						$(".tab3 .single-bottom").hide();
						$(".tab2 .single-bottom").hide();
						$(".tab1 .single-bottom").hide();
					})
					$(".tab5 ul").click(function(){
						$(".tab5 .single-bottom").slideToggle(300);
						$(".tab4 .single-bottom").hide();
						$(".tab3 .single-bottom").hide();
						$(".tab2 .single-bottom").hide();
						$(".tab1 .single-bottom").hide();
					})
				});
			</script>
			<!-- script -->
	</section>

	<section  class="sky-form">
		<h4><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>折扣</h4>
		<div class="row row1 scroll-pane">
			<div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>折扣商品(20)</label>
			</div>
			<div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>1 - 2折 (5)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>2 - 3折 (7)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>3 - 4折 (2)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>4 - 5折 (5)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>5 - 6折 (7)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>6 - 7折 (2)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>其他(50)</label>
			</div>
		</div>
	</section>

	<section  class="sky-form">
		<h4><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>价格</h4>
		<ul class="dropdown-menu1">
			<li><a href="">
				<div id="slider-range"></div>
				<input type="text" id="amount" style="border: 0; font-weight: NORMAL;   font-family: 'Dosis-Regular';" />
			</a></li>
		</ul>
	</section>
	<!---->
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	<script type='text/javascript'>//<![CDATA[
	$(window).load(function(){
		$( "#slider-range" ).slider({
			range: true,
			min: 0,
			max: 10000,
			values: [ 0, 10000 ],
			slide: function( event, ui ) {  $( "#amount" ).val( "￥" + ui.values[ 0 ] + " - ￥" + ui.values[ 1 ] );
			}
		});
		$( "#amount" ).val( "￥" + $( "#slider-range" ).slider( "values", 0 ) + " - ￥" + $( "#slider-range" ).slider( "values", 1 ) );

	});//]]>
	</script>
	<!---->


	<section  class="sky-form">
		<h4><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>功效</h4>
		<div class="row row1 scroll-pane">

			<div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>补水保湿   (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>控油细肤      (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>提拉紧致        (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>劲爽通透  (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>吸黑去黄  (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>紧致轮廓  (30)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>抚平痘痘肌  (30)</label>
			</div>
		</div>
	</section>
	<section  class="sky-form">
		<h4><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>品牌</h4>
		<div class="row row1 scroll-pane">

			<div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>兰蔻(lancome)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>资生堂(shiseido)  </label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>雅诗兰黛(estee lauder) </label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>迪奥(dior)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox" ><i></i>香奈儿(chanel)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>碧欧泉(biotherm)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>赫莲娜(hr)</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i> 伊丽莎白·雅顿(ea) </label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i> 百雀羚 </label>
			</div>
		</div>
	</section>
</div>
</div>
</div>
</div>
<!---->
</div>
<!--footer-->
<div class="footer-section">
	<div class="container">
		<div class="footer-grids">
			<div class="col-md-1 footer-grid">
			</div>
			<div class="col-md-2 footer-grid">
				<h4>新手指南</h4>
				<ul>
					<li><a href="products.html">购物流程</a></li>
					<li><a href="#">优惠券规则</a></li>
					<li><a href="#">联系客服</a></li>
					<li><a href="#">常见问题</a></li>

				</ul>
			</div>
			<div class="col-md-2 footer-grid">
				<h4>付款方式</h4>
				<ul>
					<li><a href="#">在线支付</a></li>
					<li><a href="#">货到付款</a></li>
					<li><a href="#">钱包支付</a></li>

				</ul>
			</div>
			<div class="col-md-2 footer-grid">
				<h4>配送方式</h4>
				<ul>
					<li><a href="#">配送时效及运费</a></li>
					<li><a href="#">验货与签收</a></li>

				</ul>
			</div>
			<div class="col-md-2 footer-grid">
				<h4>售后服务</h4>
				<ul>
					<li><a href="#">退货政策</a></li>
					<li><a href="#">退货流程</a></li>
					<li><a href="#">退货方式及时效</a></li>
				</ul>
			</div>
			<div class="col-md-2 footer-grid">
				<h4>部分合作网站</h4>
				<ul>
					<li><a href="www.lancome.com">兰蔻</a></li>
					<li><a href="#">雅诗兰黛</a></li>
					<li><a href="#">百雀羚</a></li>
				</ul>
			</div>
			<div class="col-md-1 footer-grid">
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-12 footer-grid1">
			<div class="col-md-5 footer-grid">
			</div>
			<div class="col-md-2 social-icons">
				<a href="#"><i class="icon"></i></a>
				<a href="#"><i class="icon1"></i></a>
				<a href="#"><i class="icon2"></i></a>
				<a href="#"><i class="icon3"></i></a>
				<a href="#"><i class="icon4"></i></a>
				<p>Copyright &copy; 易购商城</p>
			</div>
			<div class="col-md-5 footer-grid">
			</div>
		</div>
	</div>
</div>
<!--footer-->

</body>
</html>