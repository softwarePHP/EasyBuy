<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>购物车</title>
	<link href="/EASYBUY2/Public/home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
	<link href="/EASYBUY2/Public/home/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="/EASYBUY2/Public/home/css/owl.carousel.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Swim Wear Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<style type="text/css">
		.button{
			background-color:#fff;
			margin-bottom: 10px;
		}
		.delivery{
			margin-bottom: 10px;
		}
	</style>
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<script src="/EASYBUY2/Public/home/js/jquery.min.js"></script>
	<!-- cart -->
	<script src="/EASYBUY2/Public/home/js/simpleCart.min.js"> </script>
	<!-- cart -->
	<script type="text/javascript" src="/EASYBUY2/Public/home/js/bootstrap-3.1.1.min.js"></script>
	<script src="/EASYBUY2/Public/home/js/imagezoom.js"></script>

	<!-- FlexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

	<script>
		// Can also be used with $(document).ready()
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				controlNav: "thumbnails"
			});
		});
	</script>



</head>
<body>
<!--header-->
<div class="header">
	<div class="header-top">
		<div class="container">
			<div class="top-right">
				<ul>
					<li class="text"><a href="login.html">登录</a>
					<li><div class="cart box_1">
						<a href="checkout.html">
							<span class="simpleCart_total"> $0.00 </span> (<span id="simpleCart_quantity" class="simpleCart_quantity"> 0 </span>)
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">清空购物车</a></p>
						<div class="clearfix"> </div>
					</div></li>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="header-bottom">
		<div class="container">
			<!--/.content-->
			<div class="content white">
				<nav class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1 class="navbar-brand"><a  href="index.html">Easy Buy</a></h1>
					</div>
					<!--/.navbar-header-->

					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="index.html">主页</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">女士<b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-3">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">女士</a></li>-->
												<li><a class="list1" href="products.html">兰蔻(lancome)</a></li>
												<li><a class="list1" href="products.html">资生堂(shiseido)</a></li>
												<li><a class="list1" href="products.html">雅诗兰黛(estee lauder)</a></li>
												<li><a class="list1" href="products.html">迪奥(dior)</a></li>
												<li><a class="list1" href="products.html">香奈儿(chanel)</a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<!--<li><a class="list" href="products.html">男士</a></li>-->
												<li><a class="list1" href="products.html">碧欧泉(biotherm)</a></li>
												<li><a class="list1" href="products.html">赫莲娜(hr)</a></li>
												<li><a class="list1" href="products.html">伊丽莎白·雅顿(ea)</a></li>
												<li><a class="list1" href="products.html">百雀羚</a></li>
												<li><a class="list1" href="products.html"> </a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">

												<li><a class="list1" href="products.html">温碧泉</a></li>
												<li><a class="list1" href="products.html">植美村</a></li>
												<li><a class="list1" href="products.html">相宜本草</a></li>
												<li><a class="list1" href="products.html">欧莱雅</a></li>
												<li><a class="list1" href="products.html">丸美</a></li>
											</ul>
										</div>
									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">男士 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-2">
									<div class="row">
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">碧欧泉</a></li>
												<li><a class="list1" href="products.html">娇韵诗</a></li>
												<li><a class="list1" href="products.html">兰蔻</a></li>
												<li><a class="list1" href="products.html">欧珀莱</a></li>
												<li><a class="list1" href="products.html">资生堂</a></li>
											</ul>
										</div>
										<div class="col-sm-5">
											<ul class="multi-column-dropdown">
												<li><a class="list1" href="products.html">倩碧</a></li>
												<li><a class="list1" href="products.html">阿迪达斯</a></li>
												<li><a class="list1" href="products.html">雅男士</a></li>
												<li><a class="list1" href="products.html">杰士派</a></li>
												<li><a class="list1" href="products.html">高夫</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">儿童 <b class="caret"></b></a>
								<ul class="dropdown-menu multi-column columns-1">
									<div class="row">
										<div class="col-sm-1">
											<ul class="multi-column-dropdown">
												<li><a class="list1" style="width:150px;" href="products.html">强生(Johnson)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝亲(Pigeon)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">施巴(Sebamed)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">妙思乐(mustela)</a></li>
												<li><a class="list1" style="width:150px;" href="products.html">贝比拉比</a></li>
											</ul>
										</div>

									</div>
								</ul>
							</li>
							<li><a href="products.html">每日精选</a></li>

						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
				<!--/.navbar-->
			</div>
			<div class="search-box">
				<div id="sb-search" class="sb-search">
					<form>
						<input class="sb-search-input" placeholder="Enter your search term..." type="search" name="search" id="search">
						<input class="sb-search-submit" type="submit" value="">
						<span class="sb-icon-search"> </span>
					</form>
				</div>
			</div>

			<!-- search-scripts -->
			<script src="/EASYBUY2/Public/home/js/classie.js"></script>
			<script src="/EASYBUY2/Public/home/js/uisearch.js"></script>
			<script>
				new UISearch( document.getElementById( 'sb-search' ) );
			</script>
			<!-- //search-scripts -->
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--header-->
<div class="content">
	<!-- checkout -->
	<div class="content">
		<div class="cart-items">
			<div class="container">
				<h2>我的购物车 (3)</h2>
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
					});
				});
				</script>
				<div class="cart-header">
					<div class="close1"> </div>
					<div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
							<img src="/EASYBUY2/Public/home/images/1995.png" class="img-responsive" alt="">
						</div>
						<div class="cart-item-info">
							<h3><a href="#"> 韩国代购爱茉莉唇釉 </a>
								<ul class="qty">
									<li><p>订单价值:</p></li>
									<li><p>免邮费</p></li>
								</ul>

								<div class="delivery">
									<p>本商品售价 : $60.00</p>
									<div class="clearfix"></div>
								</div>
						</div>
						<div class="subscribe2">
							<a href="order.html" class="button">支付</a>
						</div>


						<div class="clearfix"></div>

					</div>
				</div>
				<script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
						$('.cart-header2').fadeOut('slow', function(c){
							$('.cart-header2').remove();
						});
					});
				});
				</script>
				<div class="cart-header2">
					<div class="close2"> </div>
					<div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
							<img src="/EASYBUY2/Public/home/images/kk.png" class="img-responsive" alt="">
						</div>
						<div class="cart-item-info">
							<h3><a href="#"> 梦妆美瞳纤长睫毛膏 </a>
								<ul class="qty">
									<li><p>订单价值:</p></li>
									<li><p>免邮费</p></li>
								</ul>
								<div class="delivery">
									<p>本商品售价 : $100.00</p>
									<div class="clearfix"></div>

								</div>

						</div>
						<a href="order.html" class="button">支付</a>
						<div class="clearfix"></div>

					</div>
				</div>
				<script>$(document).ready(function(c) {
					$('.close3').on('click', function(c){
						$('.cart-header3').fadeOut('slow', function(c){
							$('.cart-header3').remove();
						});
					});
				});
				</script>
				<div class="cart-header3">
					<div class="close3"> </div>
					<div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
							<img src="/EASYBUY2/Public/home/images/jj.png" class="img-responsive" alt="">
						</div>
						<div class="cart-item-info">
							<h3><a href="#"> 韩束红石榴鲜活水 </a>
								<ul class="qty">
									<li><p>订单价值:</p></li>
									<li><p>免邮费</p></li>
								</ul>
								<div class="delivery">
									<p>本商品售价 : $115.00</p>
									<div class="clearfix"></div>

								</div>
						</div>
						<!-- <input type="button" class="button" onclick="location='order.html'" value="支付"> -->
						<a href="order.html" class="button">支付</a>
						<div class="clearfix"></div>

					</div>
				</div>
			</div>
		</div>
		<!-- checkout -->


		<!--footer-->
		<div class="footer-section">
			<div class="container">
				<div class="footer-grids">
					<div class="col-md-1 footer-grid">
					</div>
					<div class="col-md-2 footer-grid">
						<h4>新手指南</h4>
						<ul>
							<li><a href="products.html">购物流程</a></li>
							<li><a href="#">优惠券规则</a></li>
							<li><a href="#">联系客服</a></li>
							<li><a href="#">常见问题</a></li>

						</ul>
					</div>
					<div class="col-md-2 footer-grid">
						<h4>付款方式</h4>
						<ul>
							<li><a href="#">在线支付</a></li>
							<li><a href="#">货到付款</a></li>
							<li><a href="#">钱包支付</a></li>

						</ul>
					</div>
					<div class="col-md-2 footer-grid">
						<h4>配送方式</h4>
						<ul>
							<li><a href="#">配送时效及运费</a></li>
							<li><a href="#">验货与签收</a></li>

						</ul>
					</div>
					<div class="col-md-2 footer-grid">
						<h4>售后服务</h4>
						<ul>
							<li><a href="#">退货政策</a></li>
							<li><a href="#">退货流程</a></li>
							<li><a href="#">退货方式及时效</a></li>
						</ul>
					</div>
					<div class="col-md-2 footer-grid">
						<h4>部分合作网站</h4>
						<ul>
							<li><a href="www.lancome.com">兰蔻</a></li>
							<li><a href="#">雅诗兰黛</a></li>
							<li><a href="#">百雀羚</a></li>
						</ul>
					</div>
					<div class="col-md-1 footer-grid">
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="col-md-12 footer-grid1">
					<div class="col-md-5 footer-grid">
					</div>
					<div class="col-md-2 social-icons">
						<a href="#"><i class="icon"></i></a>
						<a href="#"><i class="icon1"></i></a>
						<a href="#"><i class="icon2"></i></a>
						<a href="#"><i class="icon3"></i></a>
						<a href="#"><i class="icon4"></i></a>
						<p>Copyright &copy; 易购商城</p>
					</div>
					<div class="col-md-5 footer-grid">
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
</body>
</html>